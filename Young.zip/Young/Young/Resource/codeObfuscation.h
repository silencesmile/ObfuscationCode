#ifndef Demo_codeObfuscation_h
#define Demo_codeObfuscation_h
//confuse string at Wed Aug 30 20:39:52 CST 2017
#define hsk_Function2 VwYuEgbpUkJMPQJc
#define hsk_end AOxHipFxyUNrVkMm
#define hsk_start kMevkjKeKseLrzbY
#endif
