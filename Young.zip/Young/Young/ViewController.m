//
//  ViewController.m
//  Young
//
//  Created by Young on 2017/8/18.
//  Copyright © 2017年 Young. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)Hsk_Function2{
}
-(void)hsk_Function2{
    
}
- (void)handXXX{
    
}
- (void)hand{
    
}
- (void)hsk_start{
    
}

- (void)hsk_end{
    
}
- (void)hfunction{
    
}
- (void)_hou{
    
}


- (void)h_young{
    
}

@end
